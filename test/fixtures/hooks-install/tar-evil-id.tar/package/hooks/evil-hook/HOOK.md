---
name: evil-hook
description: Evil Hook
metadata: {"alisio":{"events":["command:new"]}}
---

# Evil Hook
