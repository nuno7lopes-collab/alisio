---
name: zip-hook
description: Zip Hook
metadata: {"alisio":{"events":["command:new"]}}
---

# Zip Hook
