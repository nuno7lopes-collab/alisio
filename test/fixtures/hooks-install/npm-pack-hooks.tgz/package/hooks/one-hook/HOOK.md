---
name: one-hook
description: One Hook
metadata: {"alisio":{"events":["command:new"]}}
---

# One Hook
