---
name: reserved-hook
description: Reserved Hook
metadata: {"alisio":{"events":["command:new"]}}
---

# Reserved Hook
