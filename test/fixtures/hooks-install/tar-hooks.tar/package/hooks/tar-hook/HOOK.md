---
name: tar-hook
description: Tar Hook
metadata: {"alisio":{"events":["command:new"]}}
---

# Tar Hook
